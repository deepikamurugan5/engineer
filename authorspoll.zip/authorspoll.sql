-- 
-- Table structure for table `authorspoll`
-- 
CREATE TABLE `authorspoll` (
  `id` int(3) NOT NULL auto_increment,
  `question` varchar(200) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 ;
-- 
-- Dumping fake data for table `authorspoll`
-- 
INSERT INTO `poll` VALUES (42, 'Charles Dickens');
INSERT INTO `poll` VALUES (41, 'Miguel de Cervantes');
INSERT INTO `poll` VALUES (40, 'J.R.R. Tolkein');
INSERT INTO `poll` VALUES (39, 'Miguel de Cervantes');
INSERT INTO `poll` VALUES (38, 'J.R.R. Tolkein');
INSERT INTO `poll` VALUES (37, 'Miguel de Cervantes');
INSERT INTO `poll` VALUES (36, 'Antoine de Saint-Exuper');
INSERT INTO `poll` VALUES (35, 'Antoine de Saint-Exuper');
INSERT INTO `poll` VALUES (21, 'Miguel de Cervantes');
INSERT INTO `poll` VALUES (22, 'Charles Dickens');
INSERT INTO `poll` VALUES (23, 'Miguel de Cervantes');
INSERT INTO `poll` VALUES (24, 'Miguel de Cervantes');
INSERT INTO `poll` VALUES (25, 'J.R.R. Tolkein');
INSERT INTO `poll` VALUES (26, 'J.R.R. Tolkein');
INSERT INTO `poll` VALUES (27, 'Miguel de Cervantes);
INSERT INTO `poll` VALUES (28, 'Charles Dickens');
INSERT INTO `poll` VALUES (29, 'Charles Dickens');
INSERT INTO `poll` VALUES (30, 'Miguel de Cervantes');
INSERT INTO `poll` VALUES (31, 'Charles Dickens');
INSERT INTO `poll` VALUES (32, 'Charles Dickens');
INSERT INTO `poll` VALUES (33, 'Miguel de Cervantes');
INSERT INTO `poll` VALUES (34, 'Miguel de Cervantes');